-- Catch the shared addon namespace parameter from the WoW engine
local addonName, FokusEraNS = ...

-- Global frame names unified with the K format
FokusEraFrame = CreateFrame("Button", "FokusEraFrame", UIParent, "SecureUnitButtonTemplate, BackdropTemplate")
FokusFrame = FokusEraFrame

-- MAIN FRAME DESIGN (FokusFrame - Height: 48)
FokusFrame:SetSize(210, 48)
FokusFrame:SetPoint("CENTER", UIParent, "CENTER", -65, -150)
FokusFrame:SetMovable(false) 
FokusFrame:SetResizable(true)
FokusFrame:SetResizeBounds(160, 48, 400, 48)
FokusFrame:EnableMouse(true)
FokusFrame:RegisterForClicks("AnyUp")
FokusFrame:Hide()

-- FORCE SECURE LAYER FORWARD OVER WEAKAURAS & SHADOW ROOT
FokusFrame:SetFrameStrata("DIALOG")
FokusFrame:SetFrameLevel(20)

FokusFrame:SetBackdrop({
    bgFile = "Interface\\Buttons\\WHITE8X8",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 8, edgeSize = 12,
    insets = { left = 2, right = 2, top = 2, bottom = 2 }
})
FokusFrame:SetBackdropColor(0, 0, 0, 0.85)
FokusFrame:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)

-- FUNCTION: Updates the width of the status bars inside the frame based on current frame width
function FokusEra_UpdateInternalWidths()
    if InCombatLockdown() then return end
    local newWidth = FokusFrame:GetWidth()
    local barWidth = newWidth - 62 
    FokusFrame.hpBar:SetWidth(barWidth)
    FokusFrame.manaBar:SetWidth(barWidth)
end

-- Redirect drag script inputs from the active template canvas to the shadow root node
FokusFrame:RegisterForDrag("LeftButton")
FokusFrame:SetScript("OnDragStart", function(self)
    if not InCombatLockdown() and not FokusEraNS.FokusEra_IsLocked and IsAltKeyDown() then
        FokusShadowFrame:StartMoving()
        
        -- FIX v1.4.0: REAL-TIME GRAPHICS SYNC UPDATE LOOP!
        -- Continuously pulls absolute coordinates from the shadow frame canvas while dragging,
        -- keeping layout strings, names, and bar textures 100% stable and visible above the background!
        FokusShadowFrame:SetScript("OnUpdate", function()
            local sLeft = FokusShadowFrame:GetLeft()
            local sBottom = FokusShadowFrame:GetBottom()
            if sLeft and sBottom and not InCombatLockdown() then
                FokusFrame:ClearAllPoints()
                FokusFrame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", sLeft, sBottom)
                if FokusEra_AlignNPCLayouts then FokusEra_AlignNPCLayouts() end
                if ReanchorTargetFrame then ReanchorTargetFrame() end
            end
        end)
    end
end)

FokusFrame:SetScript("OnDragStop", function(self)
    FokusShadowFrame:SetScript("OnUpdate", nil)
    FokusShadowFrame:StopMovingOrSizing()
    
    if not InCombatLockdown() then
        local sLeft = FokusShadowFrame:GetLeft()
        local sBottom = FokusShadowFrame:GetBottom()
        if sLeft and sBottom then
            FokusEra_ShadowX = math.floor(sLeft)
            FokusEra_ShadowY = math.floor(sBottom)
            
            FokusFrame:ClearAllPoints()
            FokusFrame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", FokusEra_ShadowX, FokusEra_ShadowY)
        end
    end
    if FokusEra_AlignNPCLayouts then FokusEra_AlignNPCLayouts() end
    if ReanchorTargetFrame then ReanchorTargetFrame() end
end)

-- Portrait sub-frames configuration
FokusFrame.staticPortrait = CreateFrame("Frame", nil, FokusFrame)
FokusFrame.portrait = CreateFrame("PlayerModel", nil, FokusFrame)
FokusFrame.portrait:SetSize(40, 38)
FokusFrame.portrait:SetPoint("TOPLEFT", FokusFrame, "TOPLEFT", 6, -5)

local portBG = FokusFrame:CreateTexture(nil, "BACKGROUND")
portBG:SetAllPoints(FokusFrame.portrait)
portBG:SetColorTexture(0.05, 0.05, 0.05, 1)

-- Master NPC Icon Overlay Frame Container
FokusFrame.iconOverlay = CreateFrame("Frame", nil, FokusFrame)
FokusFrame.iconOverlay:SetAllPoints(FokusFrame)
FokusFrame.iconOverlay:SetFrameStrata("DIALOG")
FokusFrame.iconOverlay:SetFrameLevel(FokusFrame:GetFrameLevel() + 5)
FokusFrame.iconOverlay:EnableMouse(false)
if FokusFrame.iconOverlay.SetMouseClickEnabled then FokusFrame.iconOverlay:SetMouseClickEnabled(false) end

-- Portrait Texture Overlay Anchors (Raid Mark stays clean on the top edge)
FokusFrame.raidIcon = FokusFrame.iconOverlay:CreateTexture(nil, "OVERLAY")
FokusFrame.raidIcon:SetSize(14, 14)
FokusFrame.raidIcon:SetPoint("TOPLEFT", FokusFrame, "TOPLEFT", 2, -1)
FokusFrame.raidIcon:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons")
FokusFrame.raidIcon:Hide()

-- Swapped to the pure classic spell_holy_heal texture icon file asset with border crop
FokusFrame.statusIcon = FokusFrame:CreateTexture(nil, "OVERLAY")
FokusFrame.statusIcon:SetSize(10, 10)
FokusFrame.statusIcon:SetPoint("TOPLEFT", FokusFrame, "TOPLEFT", 52, -6)
FokusFrame.statusIcon:SetTexture("Interface\\Icons\\spell_holy_heal") 
FokusFrame.statusIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
FokusFrame.statusIcon:Show() 

-- Text row pushed exactly 14 pixels to the right to make space for the status icon
FokusFrame.nameText = FokusFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
FokusFrame.nameText:SetPoint("TOPLEFT", FokusFrame, "TOPLEFT", 66, -6)
FokusFrame.nameText:SetJustifyH("LEFT")

FokusFrame.levelText = FokusFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
FokusFrame.levelText:SetPoint("TOPRIGHT", FokusFrame, "TOPRIGHT", -38, -6)
FokusFrame.levelText:SetJustifyH("RIGHT")

-- Main Health Bar
FokusFrame.hpBar = CreateFrame("StatusBar", nil, FokusFrame)
FokusFrame.hpBar:SetSize(148, 14) 
FokusFrame.hpBar:SetPoint("TOPLEFT", FokusFrame, "TOPLEFT", 52, -18)
FokusFrame.hpBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
FokusFrame.hpBar:SetStatusBarColor(0, 0.8, 0) 

FokusFrame.hpText = FokusFrame.hpBar:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
FokusFrame.hpText:SetPoint("CENTER", FokusFrame.hpBar, "CENTER", 0, 0)

-- Main Power Bar / Mana
FokusFrame.manaBar = CreateFrame("StatusBar", nil, FokusFrame)
FokusFrame.manaBar:SetSize(148, 6) 
FokusFrame.manaBar:SetPoint("TOPLEFT", FokusFrame.hpBar, "BOTTOMLEFT", 0, -2)
FokusFrame.manaBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
FokusFrame.manaBar:SetStatusBarColor(0, 0, 1)

ClickCastFrames = ClickCastFrames or {}
ClickCastFrames[FokusFrame] = true

-- INTERACTIVE CONTROL BUTTONS
FokusFrame.clearBtn = CreateFrame("Button", nil, FokusFrame)
FokusFrame.clearBtn:SetSize(12, 12)
FokusFrame.clearBtn:SetPoint("TOPRIGHT", FokusFrame, "TOPRIGHT", -6, -4)
FokusFrame.clearBtn.tex = FokusFrame.clearBtn:CreateTexture(nil, "OVERLAY")
FokusFrame.clearBtn.tex:SetAllPoints()
FokusFrame.clearBtn.tex:SetTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Up")
FokusFrame.clearBtn:SetScript("OnClick", function()
    if not InCombatLockdown() then FokusEraNS.FokusEra_ClearGroupFocusLogic() end
end)

FokusFrame.lockBtn = CreateFrame("Button", nil, FokusFrame)
FokusFrame.lockBtn:SetSize(12, 12)
FokusFrame.lockBtn:SetPoint("RIGHT", FokusFrame.clearBtn, "LEFT", -4, 0)
FokusFrame.lockBtn.tex = FokusFrame.lockBtn:CreateTexture(nil, "OVERLAY")
FokusFrame.lockBtn.tex:SetAllPoints()
FokusFrame.lockBtn.tex:SetTexture("Interface\\Buttons\\UI-OptionsButton")

-- INTERACTIVE RESIZE BUTTON
FokusFrame.resizeBtn = CreateFrame("Button", nil, FokusFrame)
FokusFrame.resizeBtn:SetSize(12, 12)
FokusFrame.resizeBtn:SetPoint("BOTTOMRIGHT", FokusFrame, "BOTTOMRIGHT", -2, 2)
FokusFrame.resizeBtn.tex = FokusFrame.resizeBtn:CreateTexture(nil, "OVERLAY")
FokusFrame.resizeBtn.tex:SetAllPoints()
FokusFrame.resizeBtn.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")

FokusFrame.resizeBtn:SetScript("OnMouseDown", function(self, button)
    if button == "LeftButton" and not InCombatLockdown() and not FokusEraNS.FokusEra_IsLocked then
        FokusFrame:SetResizable(true)
        FokusFrame:StartSizing("RIGHT") 
    end
end)

FokusFrame.resizeBtn:SetScript("OnMouseUp", function(self, button)
    FokusFrame:StopMovingOrSizing()
    FokusEra_Width = FokusFrame:GetWidth()
    FokusEra_UpdateInternalWidths()
    if FokusShadowFrame then FokusShadowFrame:SetWidth(FokusEra_Width) end
    if FokusEra_AlignNPCLayouts then FokusEra_AlignNPCLayouts() end
end)

function FokusEra_UpdateLockIconColor()
    if FokusEraNS.FokusEra_IsLocked then 
        FokusFrame.lockBtn.tex:SetVertexColor(1, 0, 0)
        FokusFrame.resizeBtn:Hide() 
    else 
        FokusFrame.lockBtn.tex:SetVertexColor(1, 0.82, 0)
        FokusFrame.resizeBtn:Show() 
    end
end

FokusFrame.lockBtn:SetScript("OnClick", function()
    FokusEraNS.FokusEra_IsLocked = not FokusEraNS.FokusEra_IsLocked
    FokusEra_SavedLockState = FokusEraNS.FokusEra_IsLocked 
    FokusEra_UpdateLockIconColor()
end)

-- INITIALIZATION PROFILE LOADING ON BOOT
local saveLoader = CreateFrame("Frame")
saveLoader:RegisterEvent("PLAYER_LOGIN")
saveLoader:SetScript("OnEvent", function(self, event)
    if FokusEra_SavedLockState ~= nil then FokusEraNS.FokusEra_IsLocked = FokusEra_SavedLockState
    else FokusEra_SavedLockState = false end
    if FokusEra_Width == nil then FokusEra_Width = 210 end 
    
    FokusFrame:SetWidth(FokusEra_Width) 
    FokusFrame.resizeBtn:SetParent(FokusFrame)
    FokusEra_UpdateInternalWidths() 
    FokusEra_UpdateLockIconColor() 
    
    if FokusFrame.portrait and FokusFrame.portrait.SetUnit then
        FokusFrame.portrait:SetUnit("player")
        FokusFrame.portrait:SetCamera(0)
        FokusFrame.portrait:SetPosition(0, 0, 0)
    end
    
    if FokusShadowFrame then FokusShadowFrame:SetWidth(FokusEra_Width) end
    if FokusEra_AlignNPCLayouts then FokusEra_AlignNPCLayouts() end
    saveLoader:UnregisterEvent("PLAYER_LOGIN")
end)

-- end fokusui.lua